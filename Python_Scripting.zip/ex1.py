def ruler(n):
    for i in range(n+1):
        if i==0:
            print("",end="")
        elif i%10==0:
            print(int(i/10),end="")
        else:
            print(" ",end="")
    print("")
    for i in range(1,n+1):
        if i>9:
            print(int(i%10),end="")
        else:
            print(i,end="")
n = int(input("Enter a limit: "))
ruler(n)

