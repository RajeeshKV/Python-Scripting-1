def isListOfInts(val):
	if type(val) is not list:
		raise ValueError(str(val) + " Invalid argument")
	else:
		if len(val) is 0:
			return True
		else:
			count = 0
			for i in val:
				if type(val) is not int:
					count = 1
			if count == 0:
				return True
			else:
				return False
def testList(list):
	print(isListOfInts(list))
testList([])
testList([1])
testList([1,2])
testList([0])
testList(['1'])
testList([1,'a'])
testList(['a',1])
testList([1, 1.])
testList([1., 1.])
testList((1,2))
