import sys

def isWhiteLine(string):
	if not string or string.isspace():
		return True
	else:
		return False

if len(sys.argv)>1:
	count = 0
	with open(sys.argv[1]) as file:
   		string = file.readline()
   		while  string:
   			if isWhiteLine(string):
   				count = count + 1
   			string = file.readline()
   		file.close()
	if count > 0:
		print("Blank string found")
else:
	string = input("Enter a string: ")
	if isWhiteLine(string):
		print("Blank string found")